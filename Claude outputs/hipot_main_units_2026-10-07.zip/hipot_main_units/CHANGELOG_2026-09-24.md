# Zmiany — 24.09.2026

Podstawa: logi stanowiska serwisowego z 23 i 24.09.2026
(`hipot_20260923.log`, `hipot_20260924.log`, `config_audit.log`).

## Co pokazały logi

942 potwierdzone cykle, 901 wyników PASS, **0 wyników FAIL**.
Odrzuconych albo straconych sztuk: ok. 60. Rozkład przyczyn:

| ile | przyczyna |
|----:|-----------|
| 25× | start nieudany: `WriteFile failed (PermissionError 13)` |
| 32× | `Odrzucono PASS – Krok 1: tylko 1 pomiarow obciazenia` |
|  8× | `kod JUDG 112 nie jest koncowym wynikiem produktu` |

Raporty: 896 zapisanych na `Z:\`, 5 awaryjnie (krótka niedostępność udziału
23.09 przed przemapowaniem). Ścieżka sieciowa działa.

---

## 1. Próg próbek obniżony z 2 na 1 (tymczasowo)

`safety_rules.MIN_IN_RANGE_SAMPLES = 1`.

Przy 9600 bodach jeden obrót pętli (status + FETCh) trwa ~183 ms, a okno
liczące się jako dowód obciążenia to dwell 1,0 s. Krok 1 kończył z dwiema
próbkami przy wymaganych dwóch — zero zapasu — i 32 razy na 933 cykle
wypadła jedna, więc dobra sztuka dostawała „Test nieważny".

Przy jednej próbce nadal muszą się zgadzać: napięcie maksymalne ≥ 90%
nastawy, prąd końcowy w zakresie Low–High, brak serii przekroczeń Max Limit.

**Po przejściu na 19200 przywrócić 2.** Wartość 0 jest zablokowana twardo —
`safety_rules` rzuca błąd przy starcie, a builder ma na to marker.

## 2. Próbki z pętli potwierdzania startu liczą się do kroku 1

Chroma zaczyna wykonywać krok 1 natychmiast po `SAFEty:STARt`, a aplikacja
przez ~0,5 s potwierdzała, że cykl ruszył — i te odczyty wyrzucała.
Stąd 2 próbki na kroku 1 wobec 5 na krokach 2–5.

`ChromaDevice.start_test(on_measurement=...)` oddaje teraz każdy odczyt
z pętli potwierdzania. To te same pomiary, z tego samego cyklu, tylko
wykonane chwilę wcześniej.

## 3. Ponowienie startu po zaniku portu

25 z 26 nieudanych startów to `WriteFile failed (PermissionError 13)` —
przejściówka USB-RS232 znikała z systemu w czasie postoju z otwartą klapą
(mediana 23 s, maks. 415 s), a aplikacja dowiadywała się o tym dopiero
przy pierwszym zapisie.

`ChromaDevice.reopen_port()` zamyka i otwiera port od nowa; `start_test`
robi **jedno** ponowienie, gdy błąd jest błędem portu. Błąd merytoryczny
testera ponowienia nie uruchamia — reconnect w takim wypadku maskowałby
usterkę. `request_stop` odzyskuje port tak samo, bo ten sam zanik dawał
komunikat „Nie potwierdzono zatrzymania testera".

## 4. Stan końcowy testera musi się potwierdzić

Pojedynczy błędnie złożony pakiet przy 9600 wyglądał jak koniec cyklu po
~2,5 s z 12 s; aplikacja sięgała po wynik i dostawała `JUDG 112`
(„krok w toku"), czyli odrzucała poprawną sztukę.

Teraz stan końcowy musi się powtórzyć w **dwóch** kolejnych pełnych
obrotach pętli, a przed upływem minimalnego czasu cyklu — w **trzech**.
Potwierdzenie to pełny obrót (status + FETCh), nie ponowny odczyt tego
samego bufora.

## 5. Zwłoka startu po zamknięciu klapy — konfigurowalna

`INTERLOCK_START_DELAY_S`, domyślnie **0,5 s**, zakres 0–5 s, pole
**Panel inżynieryjny → Interlock → „Zwłoka startu [s]"**. Nie wymaga
przebudowy EXE.

Warunki startu sprawdzane są PO odliczeniu — otwarcie klapy w trakcie
przerywa je. Zwłoka niczego nie osłabia, tylko przesuwa w czasie.

**Uwaga do diagnozy:** dane z logów nie potwierdzają, że szybkie zamknięcie
klapy powoduje błąd startu. Najkrótszy postój klapy przed nieudanym startem
to 8,3 s (mediana 23 s), a wśród 942 udanych startów są zamknięcia po
0,06 s. Zwłoka jest do dobrania na stanowisku, ale przyczyną tych 25 błędów
był zanik portu (punkt 3).

---

## Testy

37 testów regresyjnych, w tym nowy `test_station_failures_2026_09_23`
odtwarzający wszystkie trzy tryby awarii. Sprawdzone, że po cofnięciu
każdej z poprawek osobno test upada.

## Przed uruchomieniem na stanowisku

1. `station_config.json` w tej paczce ma wartości stanowiska odtworzone
   z dziennika audytowego (`Branch_1.2`, COM4, COM3, 9600, `Z:\`).
   **Sprawdź je przed pierwszym uruchomieniem** — jeśli na stanowisku są
   inne, nadpisz plik tym ze stanowiska i dopisz do niego jedną linię:
   `"INTERLOCK_START_DELAY_S": 0.5`.
2. Wynik FAIL nie wystąpił ani razu w 942 cyklach. Ścieżka FAIL nadal nie
   ma potwierdzenia z tego stanowiska.
3. Po przejściu na 19200: `MIN_IN_RANGE_SAMPLES` z powrotem na 2.
