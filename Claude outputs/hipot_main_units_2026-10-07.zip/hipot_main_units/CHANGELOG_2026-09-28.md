# Zmiany — 28.09.2026

Podstawa: `hipot_20260928.log` i `config_audit.log` ze stanowiska, wersja 1.0.1.

## Co zadziałało z poprzedniej paczki

| | 23–24.09 | 28.09 |
|---|---:|---:|
| cykle | 942 | 439 |
| PASS | 901 | 425 |
| odrzucone „Krok 1: tylko 1 pomiarow" | 32 | **0** |
| starty stracone przez zanik portu | 25 | **1** |
| `Ponawiam start po odzyskaniu portu` | — | 6 |

Krok 1 ma teraz 2–3 próbki w zakresie zamiast granicznych 2, a odzyskiwanie
portu uratowało 6 sztuk, które wcześniej skończyłyby się „awarią stanowiska".

## Co nadal nie działało: JUDG 112

13 sztuk odrzuconych jako „Test nieważny". **Moja poprawka z 24.09 celowała
w złą przyczynę** — zakładałem pojedynczy błędnie złożony pakiet. Dane mówią
co innego.

Czas wystąpienia błędu pokrywa się co do sekundy z granicą kroków:

| krok z kodem 112 | czas od startu | ile razy |
|---|---:|---:|
| 2 (Ethernet 2) | 3,1 s | 1 |
| 3 (Ethernet 3) | 4,4 s; 5,7 s | 2 |
| 4 (Ethernet 4) | 6,9 s ×2 | 2 |
| 5 (Modem) | 10,5–10,9 s | 8 |

Przy kroku trwającym 2,0 s plus 0,5 s przerwy międzykrokowej to są dokładnie
momenty, w których tester **kończy krok i nie przechodzi do następnego**.
Kod 112 to wg manuala (s. 5-17) `STOP` — rejestr kroku, który się nie wykonał.

Czyli: sekwencja zatrzymuje się w trakcie, a aplikacja wyrzuca **cały** wynik,
włącznie z krokami, które już się wykonały i miały werdykt.

## Zmiana

### 1. Sekwencja zatrzymana po oblanym kroku = FAIL wyrobu

Gdy krok zwraca kod nieterminalny (112/113/114/115), decydują kroki
**wcześniejsze**:

- **któryś oblał** → sekwencja stanęła z powodu wady wyrobu. Wynik całości to
  `FAIL`, kroki niewykonane trafiają do raportu jako `Result: ---`
  z kodem 112. Sztuka idzie na NOK.
- **wszystkie zaliczyły** → powód zatrzymania nieznany, wynik nadal
  odrzucony jako nieważny. Bez zmian.

Ta zmiana może wyłącznie zamienić „test nieważny" na „FAIL". Nigdy nie
zamieni czegokolwiek w PASS.

### 2. Kody wszystkich kroków trafiają do logu

Dotąd log kończył się na `Krok N: kod JUDG 112` i nie dało się ustalić, co
zwróciły kroki wcześniejsze. Teraz przy każdym kodzie nieterminalnym
aplikacja odczytuje JUDG **wszystkich** kroków i wypisuje:

    [WYNIK] Kod nieterminalny na kroku 5 (JUDG 112). Kody wszystkich krokow:
            krok 1 (Ethernet 1)=116; krok 2 (Ethernet 2)=116; ...

To jest jedna komenda na krok, ułamek sekundy, tylko na ścieżce błędu.

### 3. Raport: `---` zamiast `Fail` na portach bez testu

`_cap` drukowało `Fail` dla wszystkiego, co nie jest `PASS` — port, którego
tester nie dotknął, byłby opisany jako wadliwy. Teraz `---`, tak jak
w istniejącej linii `ARC Result:`.

**Do potwierdzenia z właścicielem webservice:** czy parser przyjmie
`Result:\t\t---` w kroku. Jeśli nie — trzeba ustalić, co ma tam trafiać.

## Czego to NIE rozstrzyga

Nie wiem, **dlaczego** sekwencja się zatrzymuje, bo dotychczasowy log tego nie
zapisywał. Po tej zmianie następne wystąpienie odpowie na to wprost.

Dwie możliwości, obie zgodne z danymi:

- **Wyrób faktycznie oblewa.** D211219A005978 dwa razy pod rząd zatrzymał się
  na tym samym kroku 4 — to zachowanie wady, nie zakłócenia. Przez cały
  wrzesień nie padł ani jeden FAIL na 1381 cykli, co przy stanowisku
  serwisowym jest mało prawdopodobne.
- **Coś przerywa sekwencję niezależnie od wyrobu.** 5 z 12 sztuk przeszło
  potem na PASS, a 8 z 13 zatrzymań wypada przed krokiem Modem (1,5 kV,
  przełączenie scan boxa na kanał 5).

Po pierwszym wystąpieniu z nowym logiem będzie widać, który to przypadek.

## Testy

38 testów regresyjnych, nowy `test_halted_sequence_is_a_fail_not_an_invalid_test`.
Sprawdzone, że po cofnięciu poprawki test upada.

## Konfiguracja w paczce

`station_config.json`: `Branch_1.2`, **COM6** (zmiana z 28.09 09:18), COM3,
9600, `Z:\`, zwłoka startu 0,5 s. Zweryfikuj przed uruchomieniem.
